package snippet;

public class Snippet {
	public static void main(String[] args) {
		drools-spring-1.2.0.xsd
	}
}

